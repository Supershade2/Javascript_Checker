Unfinished Javascript IDE
things that were not finished: Additional webviews that use other web engines and a intellisense